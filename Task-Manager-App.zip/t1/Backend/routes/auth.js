const express = require('express');
const User = require('../model/User');
const router = express.Router();

// Register User
router.post('/register', async (req, res) => {
    const { username, password, phone } = req.body;
    try {
        const newUser = new User({ username, password, phone });
        await newUser.save();
        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        res.status(400).json({ message: 'Registration failed', error });
    }
});

// Login User
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const user = await User.findOne({ username });

        console.log(user);
        if (!user || user.password !== password) {
            return res.status(400).json({ message: 'Invalid username or password' });
        }
        res.json({ message: 'Login successful', userId: user._id });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

module.exports = router;
