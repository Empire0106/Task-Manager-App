const express = require('express');
const router = express.Router();
const Task = require('../model/Task');

// Create a new task
router.post('/', async (req, res) => {
    const newTask = new Task({
        userId: req.body.userId,
        title: req.body.title,
        completed: false,
    });
    try {
        await newTask.save();
        res.status(201).json({ message: 'Task created successfully' }); // Send JSON response
    } catch (error) {
        res.status(400).json({ error: error.message }); // Send error as JSON as well
    }
});


// Get tasks for a specific user
router.get('/:userId', async (req, res) => {
    try {
        const tasks = await Task.find({ userId: req.params.userId });
        res.status(200).json(tasks);
    } catch (error) {
        res.status(500).send(error);
    }
});

// Edit a task
router.put('/:taskId', async (req, res) => {
    try {
        await Task.findByIdAndUpdate(req.params.taskId, { title: req.body.title });
        res.status(200).send('Task updated successfully');
    } catch (error) {
        res.status(400).send(error);
    }
});

// Mark a task as completed
router.put('/complete/:taskId', async (req, res) => {
    try {
        await Task.findByIdAndUpdate(req.params.taskId, { completed: true });
        res.status(200).send('Task marked as completed');
    } catch (error) {
        res.status(400).send(error);
    }
});

// Delete a task
router.delete('/:taskId', async (req, res) => {
    try {
        await Task.findByIdAndDelete(req.params.taskId);
        res.status(200).send('Task deleted successfully');
    } catch (error) {
        res.status(400).send(error);
    }
});

// In routes/tasks.js
router.put('/edit/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { title } = req.body;

        const updatedTask = await Task.findByIdAndUpdate(id, { title }, { new: true });
        
        if (!updatedTask) {
            return res.status(404).send({ message: 'Task not found' });
        }

        res.status(200).send(updatedTask); // Send the updated task back as confirmation
    } catch (error) {
        res.status(500).send({ error: 'Failed to update task' });
    }
});



module.exports = router;
