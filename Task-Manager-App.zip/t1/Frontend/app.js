// URL for the backend API
const API_URL = 'http://localhost:3000/api/auth';
const TASK_API_URL = 'http://localhost:3000/api/tasks';

document.getElementById('loginButton').addEventListener('click', login);
document.getElementById('registerButton').addEventListener('click', register);
document.getElementById('addTaskButton').addEventListener('click', addTask);
document.getElementById('showRegister').addEventListener('click', showRegisterForm);
document.getElementById('showLogin').addEventListener('click', showLoginForm);

let userId;
let task
function showRegisterForm() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registerForm').style.display = 'block';
}

function showLoginForm() {
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('registerForm').style.display = 'none';
}

function login() {
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    fetch(`${API_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.userId) {
            userId = data.userId;
            alert('Login successful!');
            loadTasks();
            document.getElementById('auth').style.display = 'none';
            document.getElementById('taskManager').style.display = 'block';
        } else {
            alert(data.message);
        }
    })
    .catch(error => console.error('Error during login:', error));
}

function register() {
    const username = document.getElementById('registerUsername').value;
    const password = document.getElementById('registerPassword').value;
    const phone = document.getElementById('registerPhone').value;

    fetch(`${API_URL}/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, phone })
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        if (data.message === 'User registered successfully') {
            showLoginForm();
        }
    })
    .catch(error => console.error('Error during registration:', error));
}

function addTask() {
    const title = document.getElementById('taskTitle').value;

    if (!title) {
        alert('Please enter a task title.');
        return;
    }

    console.log("Adding task:", title); // Log the task title being added

    fetch(TASK_API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, title }) // Ensure userId and title are sent
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(() => {
        console.log("Task added successfully"); // Log success
        document.getElementById('taskTitle').value = ''; // Clear the input field
        loadTasks(); // Reload tasks to reflect the newly added task
    })
    .catch(error => console.error('Error adding task:', error));
}

function loadTasks() {
    fetch(`${TASK_API_URL}/${userId}`)
    .then(response => response.json())
    .then(tasks => {
        const taskList = document.getElementById('taskList');
        taskList.innerHTML = '';
        tasks.forEach(task => {
            const li = document.createElement('li');
            li.innerText = task.title;
            li.classList.add('task-item');
            if (task.completed) {
                li.classList.add('completed');
                li.style.textDecoration = 'line-through';
                li.style.color = 'green';
            }

            const editButton = document.createElement('button');
            editButton.innerText = 'Edit';
            editButton.addEventListener('click', () => openEditModal(task._id, task.title));

            const completeButton = document.createElement('button');
            completeButton.innerText = task.completed ? 'Completed' : 'Complete';
            completeButton.disabled = task.completed;
            completeButton.addEventListener('click', () => completeTask(task._id, li));

            const deleteButton = document.createElement('button');
            deleteButton.innerText = 'Delete';
            deleteButton.addEventListener('click', () => deleteTask(task._id));

            li.appendChild(editButton);
            li.appendChild(completeButton);
            li.appendChild(deleteButton);
            taskList.appendChild(li);
        });
    })
    .catch(error => console.error('Error loading tasks:', error));
}

let currentTaskId = null; // To store the ID of the task being edited

function openEditModal(taskId, currentTitle) {
    currentTaskId = taskId; // Store the ID of the task being edited
    document.getElementById('editTaskInput').value = currentTitle; // Set the current title in the input box
    document.getElementById('editModal').style.display = 'block'; // Show the modal
}

function closeModal() {
    document.getElementById('editModal').style.display = 'none'; // Hide the modal
    currentTaskId = null; // Reset the task ID
}

function saveTask() {
    const updatedTitle = document.getElementById('editTaskInput').value;
    
    // Check if the title and ID are available
    console.log("Saving task:", currentTaskId, "with title:", updatedTitle);

    fetch(`http://localhost:3000/api/tasks/edit/${currentTaskId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title: updatedTitle }) // Send the updated title in the request body
    })
    .then(response => {
        if (response.ok) {
            console.log("Task updated successfully.");
            loadTasks(); // Reload tasks to show the updated title
            closeModal(); // Close the modal after saving
        } else {
            console.error("Error updating task:", response.statusText);
        }
    })
    .catch(error => console.error("Error updating task:", error));
}

function completeTask(taskId, taskElement) {
    fetch(`${TASK_API_URL}/complete/${taskId}`, {
        method: 'PUT'
    })
    .then(() => {
        // Apply style changes directly to the task text
        taskElement.classList.add('completed');
        taskElement.style.textDecoration = 'line-through';
        taskElement.style.color = 'green';
        taskId.completed=true;
    })
    .catch(error => console.error('Error completing task:', error));
}


function deleteTask(taskId) {
    fetch(`${TASK_API_URL}/${taskId}`, {
        method: 'DELETE'
    })
    .then(() => loadTasks())
    .catch(error => console.error('Error deleting task:', error));
}
